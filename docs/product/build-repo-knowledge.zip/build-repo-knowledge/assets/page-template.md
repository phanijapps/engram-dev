---
schema_version: "1"
id: "{{stable_id}}"
title: "{{title}}"
kind: "{{kind}}"
summary: "{{supported_summary}}"
aliases: []
technical_names: []
tags: []
systems: []
domains: []
taxonomy_ids: []
ontology_type: "{{ontology_type}}"
relationship_ids: []
evidence_ids: []
evidence_statuses: []
lifecycle: "active"
sources:
  - repository_id: "{{repository_id}}"
    revision: "{{revision}}"
    path: "{{source_relative_path}}"
    locator: "{{source_locator}}"
    content_hash: "{{source_content_hash}}"
knowledge_versions:
  taxonomy: "{{taxonomy_version}}"
  ontology: "{{ontology_version}}"
  compiler_rules: "{{compiler_rules_version}}"
coverage_gaps: []
---

<!-- generated:start -->
# {{title}}

{{supported_summary}}

## Names and classification
{{aliases_technical_names_categories}}

## Properties and behavior
{{supported_fields_constraints_rules}}

## Relationships
{{linked_relationships_with_status}}

## Evidence
{{source_links_and_locators}}

## Open questions and freshness
{{uncertainties_conflicts_coverage}}
<!-- generated:end -->

<!-- human:start -->
<!-- Preserve user notes in this section. -->
<!-- human:end -->
