# Identity and reconciliation

Extract locally before attempting cross-repository alignment. Compare explicit identifier mapping, transformations, contract bindings, calls, and schema references. Matching names, field shapes, or embeddings produce candidates only.

Represent mappings explicitly with source and target IDs, mapping kind, evidence, acceptance state, and version. Distinguish equivalence, representation, lookup, transformation, and subtype. Direction matters. A lossy transformation is not equivalence. Record composite keys, namespace, tenant scope, and conversion rules when supported.

Keep each representation intact even when related to a shared concept. Preserve contradictory field types, constraints, and rules with their source revisions. Avoid selecting a universal source of truth automatically. Record any user-supplied precedence rule explicitly and retain conflicting evidence.

On updates, fingerprint source units and recompute affected facts and dependent mappings, pages, and edges. Stable IDs persist across revisions. Detect renames through explicit identity registry updates, not silent heuristic merges. Re-evaluate mapping decisions whose evidence changed.

Only retire absent artifacts after a successful, comparable scan of their source scope. Failed access and narrower scope cause stale coverage, not deletion. Preserve human annotations outside generated content. Report changed, added, retired, stale, and unresolved findings separately.
