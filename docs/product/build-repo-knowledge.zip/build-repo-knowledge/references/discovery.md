# Repository discovery

Start with file inventory and repository instructions. Record commit, root, languages, source roots, build manifests, generated directories, exclusions, and inaccessible components. Exclude dependencies, secrets, binaries, and build output by default; inspect generated contracts when they are the only accessible definition and mark their origin.

Search by purpose rather than a fixed framework list:

| Purpose | Evidence patterns |
|---|---|
| State and structure | Types, persistence models, migrations, table definitions, platform metadata, serializers |
| Interfaces | Routes, handlers, RPC definitions, CLI interfaces, client bindings, schemas |
| Messages | Payload types, publisher and consumer calls, topic bindings, routing configuration |
| Rules | Validation, guards, calculations, transitions, orchestration, policy configuration |
| Relationships | Foreign keys, references, lookups, joins, identifier mappings, call arguments |
| System boundaries | Modules, deployment configuration, package dependencies, ownership declarations |

Adapt to any language. Detect conventions, inspect representative artifacts, then expand coverage. Use AST, symbol resolution, or LSP tools when available. Text search locates candidates; it does not establish semantic equivalence. Resolve aliases, imports, inheritance, generated types, configuration indirection, and call sites as evidence permits.

Follow definitions into tests and usages. Tests support intended behavior, not proof of runtime behavior. Cite documentation claims as documentation claims. Do not fetch external dependencies or contact production systems without task authorization.

Checkpoint by source unit for large repositories. Maintain processed/pending/failed units and extraction fingerprints. Unknown formats, reflection, runtime configuration, absent metadata, and unresolved imports must appear in coverage gaps. Record external references as unresolved boundary nodes without asserting unavailable internals.
