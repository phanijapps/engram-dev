# Searchable wiki

Generate a Markdown wiki at the user-provided destination by default. Keep knowledge artifacts in a separate machine-readable directory. Generate pages by stable ID for systems, concepts, entities, interfaces, messages, rules, and workflows supported by evidence. Build indexes by system, category, and concept.

Populate `assets/page-template.md` with concise supported explanations, exact symbols, aliases, fields, related artifacts, evidence, unresolved questions, and freshness. Omit unsupported sections rather than fabricate answers. Link related pages and revision-specific sources. Expose accepted inferences as such; never present them as direct evidence.

Produce a JSON search index containing page ID, relative path, title, aliases, exact technical names, categories, system, and searchable text. Provide a working search entry point using existing wiki search or a small local full-text search command. An index file alone is not a usable search experience. Return page links and evidence in results. Support exact identifiers and alias lookup; test business-language queries. Add semantic search only if requested or justified by failed retrieval evaluation.

Separate generated text from user notes through marked sections or companion files. Write into a staging location; validate references and search, then replace only managed files. Keep a managed-file manifest. Never overwrite an unrelated destination file or remove human content. Adapt publication to an existing destination rather than silently moving it to a new platform.

Search mode queries the existing graph/wiki without refreshing repositories unless requested. State freshness and evidence limits with the results.

## YAML front matter contract

Emit valid YAML front matter on every generated wiki page using `assets/page-template.md`. Populate aliases, exact technical names, tags, systems, domains, taxonomy IDs, ontology type, relationship IDs, evidence IDs, evidence statuses, lifecycle, source locators and revisions, and knowledge versions from validated artifacts. Use lists for multi-valued fields and keep unsupported lists empty. Omit unknown optional scalars rather than invent values. Never leave template placeholders in published pages. Serialize YAML with a YAML library to escape quotes, colons, and multiline values safely.

Allow multiple source records for pages spanning artifacts or repositories. Keep mixed evidence statuses explicit rather than assigning a misleading single status. Front matter is generated metadata; preserve human notes in the body. Build search filters from front matter and validate referenced graph and evidence IDs. Do not add wall-clock timestamps to deterministic page content; record generation time separately in the run report.
