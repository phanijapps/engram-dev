# Deterministic graph compilation

Freeze and version facts, taxonomy, ontology, accepted mappings, identity registry, and compiler rules. Specify canonical UTF-8 JSON: sorted object keys, compact separators, LF ending, and arrays sorted by stable ID where order is semantically irrelevant. Retain meaningful sequence order. Reject non-finite numbers and ambiguous duplicate IDs. Pin Unicode normalization and value normalization in the rules.

Build nodes from validated definitions and accepted facts. Build edges only through named rules with endpoint checks and evidence propagation. Edge IDs depend on relationship type, source ID, target ID, and a semantic discriminator when parallel relationships exist. Never discard distinct provenance when deduplicating an edge.

Keep ingestion timestamps, run duration, output location, and environment details in the run report outside canonical graph content. Source revision is part of evidence and remains in the frozen input. Reject invalid facts before publishing, with a diagnostic report.

Validate unique IDs, resolved endpoints or declared external stubs, evidence existence, allowed type pairs, taxonomy cycles, explicit constraints, and absence of unaccepted proposals. Compile twice from the same frozen bundle and compare hashes and bytes. Shuffle semantically unordered input collections and verify equivalent output. Do not claim these checks passed unless executed.

For small repositories a JSON graph is sufficient. A graph database is optional and must ingest the same canonical artifact. A database does not itself make extraction deterministic.

This skill provides a workflow and interchange contract, not a compiler implementation. When producing a graph, implement or reuse a versioned compiler with the rules above and record it in the manifest. Fresh LLM discovery may change the frozen input and therefore the graph.
