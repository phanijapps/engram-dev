# Knowledge model

Maintain these independent artifacts: source manifest, evidence records, extracted facts, taxonomy, ontology, mappings, proposals, accepted graph, wiki index, and run report. Validate the interchange bundle against `assets/knowledge.schema.json`.

Use repository-scoped IDs for physical artifacts and namespace-qualified IDs for domain concepts. Derive IDs from canonical identities, not timestamps, traversal order, or line numbers. Preserve an identity registry for confirmed renames. Evidence IDs may depend on source revision and locator.

Evidence includes repository ID, revision, relative path, locator, and content hash. Use line ranges for source text and JSON pointers or symbol names where appropriate. Prefer immutable revision links when a repository URL is known. Every fact includes evidence IDs and status.

Taxonomy entries define categories and parent categories. Membership is a distinct classification. Reject cycles in subtype hierarchies. Ontology entries define node types, property schemas, relationship types, permitted endpoints, optional cardinality and constraints. Record which evidence supports each definition. Unknown cardinality remains unspecified.

Classify evidence status:
- declared: explicitly stated by a definition or contract;
- implementation-supported: supported by executable logic or mapping;
- inferred: reasoned but not established;
- conflicting: incompatible evidence;
- unknown: insufficient evidence.

Maintain lifecycle separately: active, retired, stale. Inferred, conflicting, and unknown domain claims stay in proposals unless an explicit acceptance decision establishes a versioned mapping. Acceptance does not convert an inference into direct evidence; retain status and acceptance provenance. An unresolved external-reference node may exist in the graph, but carries no invented properties or asserted equivalence.

Separate a domain concept from a representation via `represents`; separate an entity definition from an instance. Avoid importing actual records by default. Record ownership only with explicit evidence. Never invent descriptions or business meanings to fill template sections.
