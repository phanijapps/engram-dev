# Evaluation protocol

Run each case against its supplied fixture with the skill and a clean output destination. Evaluate produced artifacts, not explanations alone. Keep expectations out of the execution prompt. Record fixture revision, skill version, tools, results, and failure evidence. Do not label unevaluated cases as passed.

Critical gates: every factual edge has evidence; no name-only merging; no invented runtime interactions; no unaccepted proposals in accepted graph; no lost human notes; identical frozen inputs yield identical graph bytes; search produces usable page links.

Score each dimension 0 (absent/incorrect), 1 (partial), or 2 (complete): discovery coverage, taxonomy correctness, ontology constraints, evidence quality, identity reconciliation, reproducibility, retrieval, update integrity. Require all critical gates and at least 14/16 for release.

Cases specify synthetic fixture recipes. Materialize them in isolated test directories before execution. They are not claims of completed evaluations. Exercise at least two language families and one unfamiliar representation; avoid teaching the executor the expected mapping. Repeat after changing the core workflow or output contract.
